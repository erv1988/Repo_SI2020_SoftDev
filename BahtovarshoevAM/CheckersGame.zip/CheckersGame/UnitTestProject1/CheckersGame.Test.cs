﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using CheckersGame;

namespace CheckersGame.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ResetGame()
        {
            int i = 0, j = 0;

            Form1  = new Form1();
            int actual = f.test m(i, j); 
        }
    }
}
