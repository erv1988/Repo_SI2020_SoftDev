﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CheckersGame;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckersGame.Tests
{
    [TestClass()]
    public class Form1Tests
    {
        [TestMethod()]
        public void IsInsideBordersTest()
        {
            var f = new Form1();
            Assert.AreNotEqual(true,f.IsInsideBorders(13,3));
        }

        [TestMethod()]
        public void sumTest()
        {
            Assert.AreEqual(5,Form1.sum(2,3));
        }
    }
}