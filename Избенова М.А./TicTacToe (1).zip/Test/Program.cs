﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicTacToe;
using Xunit;

namespace Test
{
    public class GameAdapter:Game
    {
        public int CheckingWinnerAcceess()
        {
            return CheckingWinner();
        }
        public bool CheckHorizontalAccess()
        {
            return CheckHorizontal();
        }

        public bool CheckDiagonalAccess()
        {
            return CheckDiagonal();
        }

        public bool CheckVerticalAccess()
        {
            return CheckVertical();
        }

        public void setCellValue(char value, int index)
        {
            cell[index] = value;
        }

        public void clearCells()
        {
            for (int i=0;i<10;i++)
            {
                cell[i] = char.Parse(i.ToString());
            }
        }
    }
    public class Tests
    {
        [Fact]
        public void VerticalTest()
        {
            GameAdapter game = new GameAdapter();

            game.setCellValue('X', 1);
            game.setCellValue('X', 4);
            game.setCellValue('X', 7);

            Assert.True(game.CheckVerticalAccess());
            game.clearCells();

            game.setCellValue('X', 2);
            game.setCellValue('X', 5);
            game.setCellValue('X', 8);

            Assert.True(game.CheckVerticalAccess());


            game.clearCells();

            game.setCellValue('X', 3);
            game.setCellValue('X', 6);
            game.setCellValue('X', 9);

            Assert.True(game.CheckVerticalAccess());

            game.clearCells();

            game.setCellValue('X', 2);
            game.setCellValue('X', 5);
            game.setCellValue('X', 9);

            Assert.False(game.CheckVerticalAccess());


            game.clearCells();

            game.setCellValue('X', 1);
            game.setCellValue('X', 5);
            game.setCellValue('X', 9);

            Assert.False(game.CheckVerticalAccess());


            game.clearCells();

            game.setCellValue('0', 1);
            game.setCellValue('X', 2);
            game.setCellValue('X', 3);

            Assert.False(game.CheckVerticalAccess());
        }

        [Fact]
        public void HorisontalTest()
        {
            GameAdapter game = new GameAdapter();

            game.setCellValue('X', 1);
            game.setCellValue('X', 2);
            game.setCellValue('X', 3);

            Assert.True(game.CheckHorizontalAccess());
            game.clearCells();

            game.setCellValue('X', 4);
            game.setCellValue('X', 5);
            game.setCellValue('X', 6);

            Assert.True(game.CheckHorizontalAccess());


            game.clearCells();

            game.setCellValue('X', 7);
            game.setCellValue('X', 8);
            game.setCellValue('X', 9);

            Assert.True(game.CheckHorizontalAccess());

            game.clearCells();

            game.setCellValue('X', 6);
            game.setCellValue('X', 8);
            game.setCellValue('X', 9);

            Assert.False(game.CheckHorizontalAccess());


            game.clearCells();

            game.setCellValue('X', 6);
            game.setCellValue('X', 7);
            game.setCellValue('X', 8);

            Assert.False(game.CheckHorizontalAccess());


            game.clearCells();

            game.setCellValue('0', 1);
            game.setCellValue('X', 2);
            game.setCellValue('X', 3);

            Assert.False(game.CheckHorizontalAccess());
        }

        [Fact]
        public void DiagonalTest()
        {
            GameAdapter game = new GameAdapter();

            game.setCellValue('X', 1);
            game.setCellValue('X', 5);
            game.setCellValue('X', 9);

            Assert.True(game.CheckDiagonalAccess());

            game.clearCells();

            game.setCellValue('X', 3);
            game.setCellValue('X', 5);
            game.setCellValue('X', 7);

            Assert.True(game.CheckDiagonalAccess());

            game.clearCells();


            game.setCellValue('X', 3);
            game.setCellValue('0', 5);
            game.setCellValue('X', 7);

            Assert.False(game.CheckDiagonalAccess());

            game.clearCells();
        }

        [Fact] 
        public void CheckWinnerTest()
        {
            GameAdapter game = new GameAdapter();

            game.clearCells();

            game.setCellValue('X', 1);
            game.setCellValue('X', 2);
            game.setCellValue('X', 3);

            Assert.Equal(1, game.CheckingWinnerAcceess());


            game.clearCells();

            game.setCellValue('X', 1);
            game.setCellValue('X', 2);
            game.setCellValue('0', 3);

            Assert.Equal(0, game.CheckingWinnerAcceess());


            game.clearCells();

            game.setCellValue('X', 1);
            game.setCellValue('O', 2);
            game.setCellValue('X', 3);
            game.setCellValue('O', 4);
            game.setCellValue('X', 5);
            game.setCellValue('O', 6);
            game.setCellValue('O', 7);
            game.setCellValue('X', 8);
            game.setCellValue('O', 9);



            Assert.Equal(-1, game.CheckingWinnerAcceess());


        }
    }
}
